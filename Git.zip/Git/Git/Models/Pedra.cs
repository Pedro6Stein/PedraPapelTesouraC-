﻿// Models/Pedra.cs
using Git.Models;

public class Pedra : Jogada
{
    public Pedra()
    {
        Nome = "Pedra";
    }

    public override string Resultado(Jogada jogadaAdversaria)
    {
        if (jogadaAdversaria is Pedra)
            return "Empate";
        else if (jogadaAdversaria is Tesoura)
            return "Você ganhou!";
        else
            return "Você perdeu!";
    }
}
