﻿// Models/Jogo.cs
using System;
using System.Collections.Generic;

public class Jogo
{
    public Jogada JogadaUsuario { get; set; }
    public Jogada JogadaComputador { get; set; }

    public string Jogar(string escolhaUsuario)
    {
        JogadaUsuario = CriarJogada(escolhaUsuario);
        JogadaComputador = CriarJogada(new[] { "Pedra", "Papel", "Tesoura" }[new Random().Next(3)]);

        return JogadaUsuario.Resultado(JogadaComputador);
    }

    private Jogada CriarJogada(string escolha)
    {
        if (escolha == "Pedra")
            return new Pedra();
        else if (escolha == "Papel")
            return new Papel();
        else
            return new Tesoura();
    }
}
