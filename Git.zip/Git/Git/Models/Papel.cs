﻿// Models/Papel.cs
public class Papel : Jogada
{
    public Papel()
    {
        Nome = "Papel";
    }

    public override string Resultado(Jogada jogadaAdversaria)
    {
        if (jogadaAdversaria is Papel)
            return "Empate";
        else if (jogadaAdversaria is Pedra)
            return "Você ganhou!";
        else
            return "Você perdeu!";
    }
}
