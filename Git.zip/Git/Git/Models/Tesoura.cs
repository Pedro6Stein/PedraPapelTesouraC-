﻿// Models/Tesoura.cs
public class Tesoura : Jogada
{
    public Tesoura()
    {
        Nome = "Tesoura";
    }

    public override string Resultado(Jogada jogadaAdversaria)
    {
        if (jogadaAdversaria is Tesoura)
            return "Empate";
        else if (jogadaAdversaria is Papel)
            return "Você ganhou!";
        else
            return "Você perdeu!";
    }
}
