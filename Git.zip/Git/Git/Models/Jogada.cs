﻿// Models/Jogada.cs
public abstract class Jogada
{
    public string Nome { get; set; }

    public abstract string Resultado(Jogada jogadaAdversaria);
}
