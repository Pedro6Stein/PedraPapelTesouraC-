// Controllers/HomeController.cs
using Microsoft.AspNetCore.Mvc;
using System;

namespace SeuProjeto.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Play(string playerChoice)
        {
            var jogo = new Jogo();
            var resultado = jogo.Jogar(playerChoice);

            ViewBag.PlayerChoice = playerChoice;
            ViewBag.ComputerChoice = jogo.JogadaComputador.Nome;
            ViewBag.Result = resultado;

            return View("Index");
        }
    }
}
